# シフト自動作成システム - 実装ガイドライン

## 1. 実装フェーズ計画

### Phase 1: 基盤構築 (Week 1-2)
- データベーススキーマ作成
- 基本的なCRUD操作実装
- 制約マスタ管理機能

### Phase 2: 制約エンジン (Week 3-4)
- 制約検証ロジック実装
- 制約違反検出システム
- 基本的な制約条件実装

### Phase 3: 生成アルゴリズム (Week 5-7)
- シフト自動生成エンジン
- 最適化アルゴリズム実装
- パフォーマンス最適化

### Phase 4: UI/UX (Week 8-9)
- シフト管理画面
- カレンダー表示
- 制約管理インターフェース

### Phase 5: 統合・テスト (Week 10)
- システム統合テスト
- パフォーマンステスト
- ユーザビリティテスト

## 2. 技術スタック

### 2.1 フロントエンド
```typescript
// 主要技術
- React 18 + TypeScript
- Tailwind CSS + Shadcn/ui
- React Query (データフェッチング)
- Zustand (状態管理)
- React Hook Form (フォーム管理)
- Date-fns (日付操作)

// カレンダーライブラリ
- React Big Calendar または FullCalendar
```

### 2.2 バックエンド
```typescript
// Supabase Functions (Edge Functions)
- TypeScript
- Deno runtime
- PostgreSQL stored procedures
- Row Level Security (RLS)
```

### 2.3 アルゴリズム実装
```typescript
// 最適化ライブラリ
- Web Workers (並列処理)
- WASM (高速計算、必要に応じて)
```

## 3. 実装優先順位

### 3.1 High Priority (必須機能)
1. **制約マスタ管理**
   - 最大連続出勤日数制約
   - 業務カバレッジ制約
   - 制約違反検出

2. **基本シフト生成**
   - 単純な割り当てアルゴリズム
   - 制約チェック機能
   - 手動調整機能

3. **シフト表示・編集**
   - カレンダー表示
   - シフト編集機能
   - 制約違反表示

### 3.2 Medium Priority (重要機能)
1. **最適化アルゴリズム**
   - 公平性最適化
   - 従業員希望考慮
   - 効率性最適化

2. **統計・分析機能**
   - シフト統計表示
   - 制約違反分析
   - パフォーマンス分析

### 3.3 Low Priority (拡張機能)
1. **高度な最適化**
   - 遺伝的アルゴリズム
   - 機械学習による最適化
   - 予測機能

## 4. データベース実装手順

### 4.1 テーブル作成順序
```sql
-- Step 1: 制約マスタテーブル
CREATE TABLE app_9213e72257_shift_constraints (...);

-- Step 2: シフトテーブル
CREATE TABLE app_9213e72257_shifts (...);

-- Step 3: 履歴テーブル
CREATE TABLE app_9213e72257_shift_generation_history (...);

-- Step 4: 制約違反ログテーブル
CREATE TABLE app_9213e72257_constraint_violations (...);

-- Step 5: 従業員希望テーブル
CREATE TABLE app_9213e72257_employee_preferences (...);
```

### 4.2 初期データ投入
```sql
-- 基本制約条件の設定
INSERT INTO app_9213e72257_shift_constraints 
(constraint_type, constraint_name, constraint_value, priority) VALUES
('max_consecutive_days', '最大連続出勤日数', '{"max_days": 6}', 100),
('daily_required_staff', '業務別必要人数', '{"min_staff": 1}', 100),
('min_rest_between_shifts', '最小休憩時間', '{"min_hours": 11}', 90),
('max_weekly_hours', '週間最大労働時間', '{"max_hours": 40}', 80);
```

### 4.3 RLS設定
```sql
-- シフトテーブルのRLS
ALTER TABLE app_9213e72257_shifts ENABLE ROW LEVEL SECURITY;

-- 従業員は自分のシフトのみ閲覧可能
CREATE POLICY "employees_view_own_shifts" ON app_9213e72257_shifts
    FOR SELECT USING (employee_id = current_setting('app.current_employee_id'));

-- 管理者は全シフト操作可能
CREATE POLICY "managers_all_shifts" ON app_9213e72257_shifts
    FOR ALL USING (current_setting('app.user_role') = 'manager');
```

## 5. フロントエンド実装構造

### 5.1 ディレクトリ構造
```
src/
├── pages/
│   ├── ShiftManagement/
│   │   ├── index.tsx
│   │   ├── ShiftCalendar.tsx
│   │   ├── ShiftGeneration.tsx
│   │   └── ShiftStatistics.tsx
│   └── ConstraintManagement/
│       ├── index.tsx
│       ├── ConstraintList.tsx
│       └── ConstraintForm.tsx
├── components/
│   ├── shift/
│   │   ├── ShiftCard.tsx
│   │   ├── ShiftEditModal.tsx
│   │   ├── GenerationProgress.tsx
│   │   └── ViolationAlert.tsx
│   └── calendar/
│       ├── CalendarView.tsx
│       ├── DayView.tsx
│       └── WeekView.tsx
├── hooks/
│   ├── useShifts.ts
│   ├── useConstraints.ts
│   ├── useShiftGeneration.ts
│   └── useShiftValidation.ts
├── utils/
│   ├── shiftGenerator.ts
│   ├── constraintValidator.ts
│   ├── dateUtils.ts
│   └── optimizationEngine.ts
└── types/
    ├── shift.ts
    ├── constraint.ts
    └── generation.ts
```

### 5.2 型定義
```typescript
// types/shift.ts
export interface Shift {
  id: string;
  shift_date: Date;
  employee_id: string;
  business_id: string;
  start_time: string;
  end_time: string;
  shift_status: 'draft' | 'confirmed' | 'published' | 'cancelled';
  assignment_type: 'auto' | 'manual' | 'adjusted';
  notes?: string;
  created_at: Date;
  updated_at: Date;
}

// types/constraint.ts
export interface Constraint {
  id: string;
  constraint_type: string;
  constraint_name: string;
  constraint_value: any;
  business_group?: string;
  employee_id?: string;
  priority: number;
  is_active: boolean;
  effective_from?: Date;
  effective_to?: Date;
}

// types/generation.ts
export interface GenerationParams {
  start_date: Date;
  end_date: Date;
  preserve_existing?: boolean;
  constraint_overrides?: ConstraintOverride[];
  optimization_goals?: OptimizationGoal[];
}
```

### 5.3 カスタムフック実装例
```typescript
// hooks/useShifts.ts
export const useShifts = (dateRange: DateRange) => {
  return useQuery({
    queryKey: ['shifts', dateRange],
    queryFn: () => getShifts(dateRange),
    staleTime: 5 * 60 * 1000, // 5分
  });
};

// hooks/useShiftGeneration.ts
export const useShiftGeneration = () => {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: generateShifts,
    onSuccess: () => {
      queryClient.invalidateQueries(['shifts']);
    },
  });
};
```

## 6. アルゴリズム実装ガイド

### 6.1 制約検証エンジン
```typescript
// utils/constraintValidator.ts
export class ConstraintValidator {
  private constraints: Constraint[] = [];

  async validateShift(shift: Shift): Promise<ConstraintViolation[]> {
    const violations: ConstraintViolation[] = [];

    for (const constraint of this.constraints) {
      const violation = await this.checkConstraint(constraint, shift);
      if (violation) {
        violations.push(violation);
      }
    }

    return violations;
  }

  private async checkConstraint(
    constraint: Constraint, 
    shift: Shift
  ): Promise<ConstraintViolation | null> {
    switch (constraint.constraint_type) {
      case 'max_consecutive_days':
        return this.checkMaxConsecutiveDays(constraint, shift);
      case 'daily_required_staff':
        return this.checkDailyRequiredStaff(constraint, shift);
      default:
        return null;
    }
  }

  private async checkMaxConsecutiveDays(
    constraint: Constraint, 
    shift: Shift
  ): Promise<ConstraintViolation | null> {
    const maxDays = constraint.constraint_value.max_days;
    const employeeShifts = await this.getEmployeeShifts(
      shift.employee_id, 
      this.getDateRange(shift.shift_date, maxDays)
    );

    const consecutiveDays = this.calculateConsecutiveDays(employeeShifts);
    
    if (consecutiveDays > maxDays) {
      return {
        constraint_id: constraint.id,
        violation_type: 'max_consecutive_days',
        severity: 'error',
        description: `従業員 ${shift.employee_id} が ${consecutiveDays} 日連続勤務となります（上限: ${maxDays}日）`,
        affected_employee_id: shift.employee_id,
        affected_date: shift.shift_date
      };
    }

    return null;
  }
}
```

### 6.2 シフト生成エンジン
```typescript
// utils/shiftGenerator.ts
export class ShiftGenerator {
  private validator: ConstraintValidator;
  private optimizer: OptimizationEngine;

  constructor() {
    this.validator = new ConstraintValidator();
    this.optimizer = new OptimizationEngine();
  }

  async generateShifts(params: GenerationParams): Promise<GenerationResult> {
    // Step 1: 初期解の生成
    const initialSolution = await this.generateInitialSolution(params);

    // Step 2: 制約違反の修正
    const feasibleSolution = await this.repairConstraintViolations(initialSolution);

    // Step 3: 最適化
    const optimizedSolution = await this.optimizer.optimize(feasibleSolution);

    // Step 4: 結果の検証
    const violations = await this.validator.validateSolution(optimizedSolution);

    return {
      shifts: optimizedSolution,
      violations,
      statistics: this.calculateStatistics(optimizedSolution)
    };
  }

  private async generateInitialSolution(params: GenerationParams): Promise<Shift[]> {
    const shifts: Shift[] = [];
    const businesses = await this.getRequiredBusinesses();
    
    for (let date = params.start_date; date <= params.end_date; date = addDays(date, 1)) {
      for (const business of businesses) {
        const availableEmployees = await this.getAvailableEmployees(date, business);
        
        if (availableEmployees.length > 0) {
          // 単純な割り当て（ラウンドロビン）
          const employee = this.selectEmployee(availableEmployees, date);
          
          shifts.push({
            id: generateId(),
            shift_date: date,
            employee_id: employee.employee_id,
            business_id: business.業務id,
            start_time: business.開始時間,
            end_time: business.終了時間,
            shift_status: 'draft',
            assignment_type: 'auto'
          });
        }
      }
    }

    return shifts;
  }
}
```

## 7. パフォーマンス最適化

### 7.1 データベース最適化
```sql
-- インデックス作成
CREATE INDEX CONCURRENTLY idx_shifts_date_employee 
ON app_9213e72257_shifts(shift_date, employee_id);

CREATE INDEX CONCURRENTLY idx_shifts_business_date 
ON app_9213e72257_shifts(business_id, shift_date);

-- パーティショニング（大量データ対応）
CREATE TABLE app_9213e72257_shifts_2024 PARTITION OF app_9213e72257_shifts
FOR VALUES FROM ('2024-01-01') TO ('2025-01-01');
```

### 7.2 フロントエンド最適化
```typescript
// React.memo でコンポーネント最適化
export const ShiftCard = React.memo(({ shift }: { shift: Shift }) => {
  return (
    <div className="shift-card">
      {/* シフト表示内容 */}
    </div>
  );
});

// useMemo でデータ変換最適化
const processedShifts = useMemo(() => {
  return shifts.map(shift => ({
    ...shift,
    duration: calculateDuration(shift.start_time, shift.end_time)
  }));
}, [shifts]);

// useCallback でイベントハンドラ最適化
const handleShiftUpdate = useCallback((shiftId: string, updates: Partial<Shift>) => {
  updateShift.mutate({ id: shiftId, ...updates });
}, [updateShift]);
```

### 7.3 Web Workers活用
```typescript
// workers/shiftGenerationWorker.ts
self.onmessage = async (event) => {
  const { type, payload } = event.data;

  switch (type) {
    case 'GENERATE_SHIFTS':
      try {
        const result = await generateShiftsInWorker(payload);
        self.postMessage({ type: 'GENERATION_SUCCESS', result });
      } catch (error) {
        self.postMessage({ type: 'GENERATION_ERROR', error: error.message });
      }
      break;
  }
};

// メインスレッドでの使用
const generateShiftsWithWorker = async (params: GenerationParams) => {
  return new Promise((resolve, reject) => {
    const worker = new Worker('/workers/shiftGenerationWorker.js');
    
    worker.postMessage({ type: 'GENERATE_SHIFTS', payload: params });
    
    worker.onmessage = (event) => {
      const { type, result, error } = event.data;
      
      if (type === 'GENERATION_SUCCESS') {
        resolve(result);
      } else if (type === 'GENERATION_ERROR') {
        reject(new Error(error));
      }
      
      worker.terminate();
    };
  });
};
```

## 8. テスト戦略

### 8.1 単体テスト
```typescript
// __tests__/constraintValidator.test.ts
describe('ConstraintValidator', () => {
  let validator: ConstraintValidator;

  beforeEach(() => {
    validator = new ConstraintValidator();
  });

  test('最大連続出勤日数制約をチェックする', async () => {
    const constraint: Constraint = {
      constraint_type: 'max_consecutive_days',
      constraint_value: { max_days: 6 }
    };

    const shift: Shift = {
      employee_id: '00000001',
      shift_date: new Date('2024-01-07')
    };

    // 6日連続勤務のシフトを設定
    mockEmployeeShifts(['2024-01-01', '2024-01-02', '2024-01-03', '2024-01-04', '2024-01-05', '2024-01-06']);

    const violation = await validator.checkConstraint(constraint, shift);
    
    expect(violation).toBeNull(); // 6日目なので違反なし
  });
});
```

### 8.2 統合テスト
```typescript
// __tests__/shiftGeneration.integration.test.ts
describe('Shift Generation Integration', () => {
  test('1週間のシフトを生成する', async () => {
    const params: GenerationParams = {
      start_date: new Date('2024-01-01'),
      end_date: new Date('2024-01-07')
    };

    const result = await generateShifts(params);

    expect(result.shifts).toHaveLength(expectedShiftCount);
    expect(result.violations).toHaveLength(0);
    expect(result.statistics.coverage_rate).toBeGreaterThan(0.95);
  });
});
```

## 9. デプロイメント

### 9.1 環境設定
```typescript
// .env.local
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key

// 本番環境用設定
NEXT_PUBLIC_APP_ENV=production
NEXT_PUBLIC_SENTRY_DSN=your_sentry_dsn
```

### 9.2 CI/CD設定
```yaml
# .github/workflows/deploy.yml
name: Deploy Shift System

on:
  push:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
      - run: npm ci
      - run: npm run test
      - run: npm run build

  deploy:
    needs: test
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
      - run: npm ci
      - run: npm run build
      - uses: vercel/action@v1
        with:
          vercel-token: ${{ secrets.VERCEL_TOKEN }}
```

この実装ガイドラインに従って、段階的にシフト自動作成システムを構築することで、品質の高いシステムを効率的に開発できます。