# シフト自動作成システム - システム設計書

## 1. システム概要

### 1.1 システム目的
既存の従業員管理・業務マスタ・スキルマトリクスシステムと統合し、業務ルールと制約条件を満たした最適なシフトを自動生成するシステムを構築する。

### 1.2 主要機能
- **シフト自動生成**: 制約条件を満たした最適なシフトの自動作成
- **制約管理**: 業務ルールの設定・管理
- **手動調整**: 自動生成されたシフトの手動修正
- **制約違反検出**: リアルタイムでの制約違反チェック
- **統計・分析**: シフト効率性と公平性の分析

### 1.3 システム要件
- **最大連続出勤日数**: 6日まで
- **業務カバレッジ**: 全業務に毎日1名以上配置
- **スキル適合**: 従業員のスキルレベルに応じた業務割り当て
- **公平性**: 労働時間の均等分散
- **柔軟性**: 従業員の希望シフト考慮

## 2. データ構造と関連性

### 2.1 ER図
```mermaid
erDiagram
    EMPLOYEES ||--o{ SHIFTS : "assigned_to"
    EMPLOYEES ||--o{ SKILL_MATRIX : "has_skills"
    EMPLOYEES ||--o{ EMPLOYEE_PREFERENCES : "has_preferences"
    
    BUSINESS_MASTER ||--o{ SHIFTS : "requires"
    BUSINESS_GROUPS ||--o{ SKILL_MATRIX : "categorizes"
    
    SHIFT_CONSTRAINTS ||--o{ CONSTRAINT_VIOLATIONS : "validates"
    SHIFTS ||--o{ CONSTRAINT_VIOLATIONS : "may_violate"
    
    SHIFT_GENERATION_HISTORY ||--o{ CONSTRAINT_VIOLATIONS : "tracks"
    
    EMPLOYEES {
        string employee_id PK
        string name
        string office
        boolean roll_call_duty
        timestamp created_at
    }
    
    BUSINESS_MASTER {
        string business_id PK
        string business_name
        time start_time
        time end_time
        string business_group
        string skill_requirement
    }
    
    SKILL_MATRIX {
        uuid id PK
        string employee_id FK
        string business_group
        string skill_level
    }
    
    SHIFTS {
        uuid id PK
        date shift_date
        string employee_id FK
        string business_id FK
        time start_time
        time end_time
        string shift_status
        string assignment_type
    }
    
    SHIFT_CONSTRAINTS {
        uuid id PK
        string constraint_type
        string constraint_name
        json constraint_value
        integer priority
        boolean is_active
    }
    
    EMPLOYEE_PREFERENCES {
        uuid id PK
        string employee_id FK
        date preference_date
        string preference_type
        integer priority
    }
```

### 2.2 クラス図
```mermaid
classDiagram
    class ShiftGenerationEngine {
        +generateShifts(params: GenerationParams): GenerationResult
        +validateConstraints(shifts: Shift[]): ConstraintViolation[]
        +optimizeAssignments(shifts: Shift[]): OptimizedShifts
        -initializeSolution(): Shift[]
        -repairViolations(shifts: Shift[]): Shift[]
    }
    
    class ConstraintValidator {
        +validateShift(shift: Shift): ConstraintViolation[]
        +checkMaxConsecutiveDays(employee: string, date: Date): boolean
        +checkBusinessCoverage(date: Date): boolean
        +checkSkillRequirements(shift: Shift): boolean
        -loadConstraints(): Constraint[]
    }
    
    class OptimizationEngine {
        +optimizeForFairness(shifts: Shift[]): Shift[]
        +optimizeForPreferences(shifts: Shift[]): Shift[]
        +optimizeForEfficiency(shifts: Shift[]): Shift[]
        -calculateFitnessScore(solution: Shift[]): number
        -applyGeneticAlgorithm(population: Shift[][]): Shift[]
    }
    
    class ShiftRepository {
        +getShifts(dateRange: DateRange): Shift[]
        +createShifts(shifts: Shift[]): void
        +updateShift(id: string, shift: Shift): void
        +deleteShift(id: string): void
    }
    
    class ConstraintRepository {
        +getConstraints(): Constraint[]
        +createConstraint(constraint: Constraint): void
        +updateConstraint(id: string, constraint: Constraint): void
        +getViolations(generationId: string): ConstraintViolation[]
    }
    
    ShiftGenerationEngine --> ConstraintValidator
    ShiftGenerationEngine --> OptimizationEngine
    ShiftGenerationEngine --> ShiftRepository
    ConstraintValidator --> ConstraintRepository
```

## 3. プログラム呼び出しフロー

### 3.1 シフト自動生成フロー
```mermaid
sequenceDiagram
    participant UI as React UI
    participant API as Supabase API
    participant Engine as ShiftGenerationEngine
    participant Validator as ConstraintValidator
    participant Optimizer as OptimizationEngine
    participant DB as Database
    
    UI->>API: POST /rpc/generate_shifts
    API->>Engine: generateShifts(params)
    
    Engine->>DB: loadEmployees()
    Engine->>DB: loadBusinessMaster()
    Engine->>DB: loadConstraints()
    Engine->>DB: loadSkillMatrix()
    
    Engine->>Engine: initializeSolution()
    
    loop For each shift
        Engine->>Validator: validateShift(shift)
        Validator->>DB: checkConstraints(shift)
        Validator-->>Engine: violations[]
    end
    
    Engine->>Engine: repairViolations(shifts)
    Engine->>Optimizer: optimize(shifts)
    
    Optimizer->>Optimizer: calculateFitnessScore()
    Optimizer->>Optimizer: applyOptimization()
    Optimizer-->>Engine: optimizedShifts
    
    Engine->>DB: saveShifts(shifts)
    Engine->>DB: saveGenerationHistory()
    Engine->>DB: saveViolations()
    
    Engine-->>API: GenerationResult
    API-->>UI: shifts, violations, statistics
```

### 3.2 制約検証フロー
```mermaid
sequenceDiagram
    participant Validator as ConstraintValidator
    participant DB as Database
    participant Logger as ViolationLogger
    
    Validator->>DB: getConstraints()
    DB-->>Validator: constraints[]
    
    loop For each constraint
        Validator->>Validator: checkConstraintType()
        
        alt Max Consecutive Days
            Validator->>DB: getEmployeeShifts(employeeId, dateRange)
            Validator->>Validator: calculateConsecutiveDays()
        else Daily Required Staff
            Validator->>DB: getShiftsForDate(date)
            Validator->>Validator: checkBusinessCoverage()
        else Skill Requirements
            Validator->>DB: getEmployeeSkills(employeeId)
            Validator->>Validator: checkSkillMatch()
        end
        
        alt Violation Found
            Validator->>Logger: logViolation(violation)
            Logger->>DB: saveViolation(violation)
        end
    end
    
    Validator-->>Validator: violations[]
```

### 3.3 最適化処理フロー
```mermaid
sequenceDiagram
    participant Optimizer as OptimizationEngine
    participant Evaluator as FitnessEvaluator
    participant DB as Database
    
    Optimizer->>Optimizer: initializePopulation()
    
    loop Generations
        loop For each individual
            Optimizer->>Evaluator: calculateFitness(individual)
            Evaluator->>Evaluator: checkFairness()
            Evaluator->>Evaluator: checkPreferences()
            Evaluator->>Evaluator: checkEfficiency()
            Evaluator-->>Optimizer: fitnessScore
        end
        
        Optimizer->>Optimizer: selection()
        Optimizer->>Optimizer: crossover()
        Optimizer->>Optimizer: mutation()
        
        alt Optimal Solution Found
            break
        end
    end
    
    Optimizer->>DB: saveOptimizationResult()
    Optimizer-->>Optimizer: bestSolution
```

## 4. 制約条件の実装

### 4.1 制約条件の優先度
```typescript
enum ConstraintPriority {
  CRITICAL = 100,  // 法的要件（労働基準法等）
  HIGH = 80,       // 業務要件（カバレッジ等）
  MEDIUM = 60,     // 効率要件（公平性等）
  LOW = 40         // 希望要件（従業員希望等）
}
```

### 4.2 制約条件の種類
```typescript
interface ConstraintTypes {
  // ハード制約（必須）
  max_consecutive_days: { max_days: number };
  daily_required_staff: { min_staff: number; max_staff?: number };
  min_rest_between_shifts: { min_hours: number };
  skill_requirements: { required_level: string };
  
  // ソフト制約（最適化目標）
  fairness_hours: { target_variance: number };
  employee_preferences: { weight: number };
  business_efficiency: { target_coverage: number };
}
```

## 5. アルゴリズム詳細設計

### 5.1 制約充足問題 (CSP) アプローチ
```typescript
class CSPSolver {
  private variables: Variable[];      // シフト割り当て変数
  private domains: Domain[];         // 各変数の取りうる値
  private constraints: Constraint[]; // 制約条件

  solve(): Solution {
    // バックトラッキング + 制約伝搬
    return this.backtrackSearch();
  }

  private backtrackSearch(): Solution {
    // 1. 変数選択（MRV: Minimum Remaining Values）
    const variable = this.selectUnassignedVariable();
    
    // 2. 値選択（LCV: Least Constraining Value）
    const values = this.orderDomainValues(variable);
    
    for (const value of values) {
      if (this.isConsistent(variable, value)) {
        // 3. 制約伝搬（AC-3: Arc Consistency）
        const inference = this.propagateConstraints(variable, value);
        
        if (inference.success) {
          const result = this.backtrackSearch();
          if (result.success) return result;
        }
        
        // バックトラック
        this.undoInference(inference);
      }
    }
    
    return { success: false };
  }
}
```

### 5.2 遺伝的アルゴリズム
```typescript
class GeneticAlgorithm {
  private populationSize = 100;
  private generations = 1000;
  private crossoverRate = 0.8;
  private mutationRate = 0.1;

  solve(problem: ShiftProblem): Solution {
    let population = this.initializePopulation(problem);
    
    for (let gen = 0; gen < this.generations; gen++) {
      // 適応度評価
      const fitness = population.map(individual => 
        this.evaluateFitness(individual)
      );
      
      // 選択
      const parents = this.selection(population, fitness);
      
      // 交叉
      const offspring = this.crossover(parents);
      
      // 突然変異
      const mutated = this.mutation(offspring);
      
      // 次世代の選択
      population = this.replacement(population, mutated, fitness);
      
      // 収束判定
      if (this.hasConverged(population)) break;
    }
    
    return this.getBestSolution(population);
  }

  private evaluateFitness(individual: Individual): number {
    let score = 0;
    
    // ハード制約違反ペナルティ
    score -= this.hardConstraintViolations(individual) * 1000;
    
    // ソフト制約最適化スコア
    score += this.fairnessScore(individual) * 100;
    score += this.preferenceScore(individual) * 50;
    score += this.efficiencyScore(individual) * 30;
    
    return score;
  }
}
```

## 6. パフォーマンス要件

### 6.1 応答時間要件
- **シフト表示**: 2秒以内
- **制約検証**: 1秒以内
- **小規模生成** (1週間, 50名): 10秒以内
- **大規模生成** (1ヶ月, 200名): 60秒以内

### 6.2 スケーラビリティ要件
- **従業員数**: 最大500名
- **業務数**: 最大100業務
- **生成期間**: 最大3ヶ月
- **同時アクセス**: 最大50ユーザー

### 6.3 最適化戦略
```typescript
class PerformanceOptimizer {
  // 並列処理による高速化
  async parallelGeneration(params: GenerationParams): Promise<GenerationResult> {
    const workers = await this.createWorkerPool(4);
    const chunks = this.divideWorkload(params);
    
    const results = await Promise.all(
      chunks.map((chunk, index) => 
        workers[index % workers.length].generate(chunk)
      )
    );
    
    return this.mergeResults(results);
  }

  // キャッシュによる高速化
  private constraintCache = new LRUCache<string, ConstraintResult>(1000);
  
  checkConstraintCached(key: string, checker: () => ConstraintResult): ConstraintResult {
    if (this.constraintCache.has(key)) {
      return this.constraintCache.get(key)!;
    }
    
    const result = checker();
    this.constraintCache.set(key, result);
    return result;
  }

  // インクリメンタル更新
  updateShiftIncremental(oldShifts: Shift[], newShift: Shift): UpdateResult {
    // 影響範囲を特定
    const affectedRange = this.calculateAffectedRange(newShift);
    
    // 部分的な再計算のみ実行
    return this.recalculatePartial(oldShifts, newShift, affectedRange);
  }
}
```

## 7. 不明点と今後の検討事項

### 7.1 業務ルールの詳細化が必要な項目
1. **休憩時間の扱い**
   - 業務間の最小休憩時間
   - 昼休憩の必須性
   - 分割勤務の可否

2. **特殊勤務の扱い**
   - 早朝・深夜手当対象業務の制限
   - 管理者必須業務の扱い
   - 緊急時対応の優先度

3. **従業員の個別制約**
   - 個人の勤務可能時間帯
   - 健康上の制約
   - 研修・会議等の予定考慮

### 7.2 最適化目標の重み付け
1. **公平性 vs 効率性**
   - 労働時間の均等化の重要度
   - 業務効率性との兼ね合い

2. **従業員希望の考慮度**
   - 希望シフトの反映率目標
   - 希望が競合した場合の調整方法

3. **コスト最適化**
   - 人件費の最小化
   - 手当支給の最適化

### 7.3 技術的検討事項
1. **アルゴリズムの選択**
   - 問題規模に応じた最適手法
   - 計算時間と解の品質のトレードオフ

2. **リアルタイム更新**
   - シフト変更時の影響範囲計算
   - 制約違反の即座検出

3. **拡張性**
   - 新しい制約条件の追加容易性
   - 業務ルール変更への対応

この設計書に基づいて実装を進めることで、要件を満たすシフト自動作成システムを構築できます。不明点については、実装過程で段階的に詳細化していく方針とします。