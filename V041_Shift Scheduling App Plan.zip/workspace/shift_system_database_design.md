# シフト自動作成システム - データベース設計書

## 1. 概要

本文書は、シフト自動作成システムのデータベース設計を定義します。既存の従業員管理、業務マスタ、スキルマトリクスシステムと統合し、制約条件を満たしたシフト自動生成を実現します。

## 2. 既存テーブル構造

### 2.1 従業員テーブル (app_9213e72257_employees)
```sql
-- 既存テーブル（参照のみ）
CREATE TABLE app_9213e72257_employees (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    employee_id VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    office VARCHAR(50),
    roll_call_duty BOOLEAN,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

### 2.2 業務マスタテーブル (app_9213e72257_business_master)
```sql
-- 既存テーブル（参照のみ）
CREATE TABLE app_9213e72257_business_master (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    業務id VARCHAR(20) UNIQUE NOT NULL,
    業務名 VARCHAR(100) NOT NULL,
    開始時間 TIME NOT NULL,
    終了時間 TIME NOT NULL,
    業務グループ VARCHAR(50),
    早朝手当 VARCHAR(10),
    深夜手当 VARCHAR(10),
    スキルマップ項目名 VARCHAR(100),
    ペア業務id VARCHAR(20),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

### 2.3 スキルマトリクステーブル (app_9213e72257_skill_matrix)
```sql
-- 既存テーブル（参照のみ）
CREATE TABLE app_9213e72257_skill_matrix (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    employee_id VARCHAR(20) NOT NULL,
    skill_name VARCHAR(100),
    business_group VARCHAR(50),
    skill_level VARCHAR(20),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

## 3. 新規テーブル設計

### 3.1 制約マスタテーブル (app_9213e72257_shift_constraints)
```sql
CREATE TABLE app_9213e72257_shift_constraints (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    constraint_type VARCHAR(50) NOT NULL, -- 'max_consecutive_days', 'min_rest_days', 'daily_required_staff', etc.
    constraint_name VARCHAR(100) NOT NULL,
    constraint_value JSONB NOT NULL, -- 柔軟な制約値格納
    business_group VARCHAR(50), -- 業務グループ固有の制約（NULL = 全体制約）
    employee_id VARCHAR(20), -- 従業員固有の制約（NULL = 全体制約）
    priority INTEGER DEFAULT 100, -- 制約の優先度（数値が大きいほど高優先度）
    is_active BOOLEAN DEFAULT TRUE,
    effective_from DATE,
    effective_to DATE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    FOREIGN KEY (employee_id) REFERENCES app_9213e72257_employees(employee_id)
);

-- インデックス
CREATE INDEX idx_shift_constraints_type ON app_9213e72257_shift_constraints(constraint_type);
CREATE INDEX idx_shift_constraints_business_group ON app_9213e72257_shift_constraints(business_group);
CREATE INDEX idx_shift_constraints_employee ON app_9213e72257_shift_constraints(employee_id);
```

### 3.2 シフトテーブル (app_9213e72257_shifts)
```sql
CREATE TABLE app_9213e72257_shifts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    shift_date DATE NOT NULL,
    employee_id VARCHAR(20) NOT NULL,
    business_id VARCHAR(20) NOT NULL, -- 業務マスタの業務id
    shift_status VARCHAR(20) DEFAULT 'draft', -- 'draft', 'confirmed', 'published', 'cancelled'
    assignment_type VARCHAR(20) DEFAULT 'auto', -- 'auto', 'manual', 'adjusted'
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    break_minutes INTEGER DEFAULT 0,
    notes TEXT,
    created_by VARCHAR(20),
    approved_by VARCHAR(20),
    approved_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    FOREIGN KEY (employee_id) REFERENCES app_9213e72257_employees(employee_id),
    FOREIGN KEY (business_id) REFERENCES app_9213e72257_business_master(業務id),
    
    -- 同一日・同一従業員・同一業務の重複防止
    UNIQUE(shift_date, employee_id, business_id)
);

-- インデックス
CREATE INDEX idx_shifts_date ON app_9213e72257_shifts(shift_date);
CREATE INDEX idx_shifts_employee ON app_9213e72257_shifts(employee_id);
CREATE INDEX idx_shifts_business ON app_9213e72257_shifts(business_id);
CREATE INDEX idx_shifts_status ON app_9213e72257_shifts(shift_status);
CREATE INDEX idx_shifts_date_employee ON app_9213e72257_shifts(shift_date, employee_id);
```

### 3.3 シフト生成履歴テーブル (app_9213e72257_shift_generation_history)
```sql
CREATE TABLE app_9213e72257_shift_generation_history (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    generation_id UUID NOT NULL, -- 同一生成処理のグループID
    target_period_start DATE NOT NULL,
    target_period_end DATE NOT NULL,
    generation_type VARCHAR(20) DEFAULT 'auto', -- 'auto', 'manual', 'partial'
    algorithm_used VARCHAR(50), -- 使用したアルゴリズム名
    generation_parameters JSONB, -- 生成時のパラメータ
    constraints_applied JSONB, -- 適用された制約条件
    generation_status VARCHAR(20) DEFAULT 'running', -- 'running', 'completed', 'failed', 'cancelled'
    total_shifts_generated INTEGER DEFAULT 0,
    constraint_violations INTEGER DEFAULT 0,
    optimization_score DECIMAL(10,2), -- 最適化スコア
    execution_time_ms INTEGER,
    error_message TEXT,
    created_by VARCHAR(20),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    completed_at TIMESTAMP WITH TIME ZONE
);

-- インデックス
CREATE INDEX idx_shift_generation_history_period ON app_9213e72257_shift_generation_history(target_period_start, target_period_end);
CREATE INDEX idx_shift_generation_history_status ON app_9213e72257_shift_generation_history(generation_status);
```

### 3.4 制約違反ログテーブル (app_9213e72257_constraint_violations)
```sql
CREATE TABLE app_9213e72257_constraint_violations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    generation_id UUID NOT NULL,
    shift_id UUID,
    constraint_id UUID NOT NULL,
    violation_type VARCHAR(50) NOT NULL,
    violation_severity VARCHAR(20) DEFAULT 'warning', -- 'info', 'warning', 'error', 'critical'
    violation_description TEXT,
    affected_employee_id VARCHAR(20),
    affected_date DATE,
    suggested_resolution TEXT,
    is_resolved BOOLEAN DEFAULT FALSE,
    resolved_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    FOREIGN KEY (shift_id) REFERENCES app_9213e72257_shifts(id),
    FOREIGN KEY (constraint_id) REFERENCES app_9213e72257_shift_constraints(id),
    FOREIGN KEY (affected_employee_id) REFERENCES app_9213e72257_employees(employee_id)
);

-- インデックス
CREATE INDEX idx_constraint_violations_generation ON app_9213e72257_constraint_violations(generation_id);
CREATE INDEX idx_constraint_violations_severity ON app_9213e72257_constraint_violations(violation_severity);
CREATE INDEX idx_constraint_violations_resolved ON app_9213e72257_constraint_violations(is_resolved);
```

### 3.5 従業員希望シフトテーブル (app_9213e72257_employee_preferences)
```sql
CREATE TABLE app_9213e72257_employee_preferences (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    employee_id VARCHAR(20) NOT NULL,
    preference_date DATE NOT NULL,
    preference_type VARCHAR(20) NOT NULL, -- 'available', 'unavailable', 'preferred', 'avoid'
    business_group VARCHAR(50), -- 特定業務グループへの希望（NULL = 全業務）
    time_slot_start TIME,
    time_slot_end TIME,
    priority INTEGER DEFAULT 50, -- 希望の強さ（1-100）
    reason TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    FOREIGN KEY (employee_id) REFERENCES app_9213e72257_employees(employee_id),
    
    -- 同一日・同一従業員・同一時間帯の重複防止
    UNIQUE(employee_id, preference_date, preference_type, time_slot_start, time_slot_end)
);

-- インデックス
CREATE INDEX idx_employee_preferences_employee ON app_9213e72257_employee_preferences(employee_id);
CREATE INDEX idx_employee_preferences_date ON app_9213e72257_employee_preferences(preference_date);
CREATE INDEX idx_employee_preferences_type ON app_9213e72257_employee_preferences(preference_type);
```

## 4. 制約条件の定義例

### 4.1 基本制約条件
```sql
-- 最大連続出勤日数制約
INSERT INTO app_9213e72257_shift_constraints (constraint_type, constraint_name, constraint_value, priority) 
VALUES ('max_consecutive_days', '最大連続出勤日数', '{"max_days": 6}', 100);

-- 業務ごとの必要人数制約
INSERT INTO app_9213e72257_shift_constraints (constraint_type, constraint_name, constraint_value, priority) 
VALUES ('daily_required_staff', '業務別必要人数', '{"min_staff": 1, "max_staff": 3}', 100);

-- 最小休憩時間制約
INSERT INTO app_9213e72257_shift_constraints (constraint_type, constraint_name, constraint_value, priority) 
VALUES ('min_rest_between_shifts', '最小休憩時間', '{"min_hours": 11}', 90);

-- 週間最大労働時間制約
INSERT INTO app_9213e72257_shift_constraints (constraint_type, constraint_name, constraint_value, priority) 
VALUES ('max_weekly_hours', '週間最大労働時間', '{"max_hours": 40}', 80);
```

## 5. Row Level Security (RLS) 設定

```sql
-- シフトテーブルのRLS
ALTER TABLE app_9213e72257_shifts ENABLE ROW LEVEL SECURITY;

-- 従業員は自分のシフトのみ閲覧可能
CREATE POLICY "employees_can_view_own_shifts" ON app_9213e72257_shifts
    FOR SELECT USING (employee_id = current_setting('app.current_employee_id'));

-- 管理者は全シフト操作可能
CREATE POLICY "managers_can_manage_all_shifts" ON app_9213e72257_shifts
    FOR ALL USING (current_setting('app.user_role') = 'manager');
```

## 6. トリガー設定

```sql
-- シフト更新時のタイムスタンプ自動更新
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_shifts_updated_at BEFORE UPDATE ON app_9213e72257_shifts
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- 制約違反チェックトリガー
CREATE OR REPLACE FUNCTION check_shift_constraints()
RETURNS TRIGGER AS $$
BEGIN
    -- 連続出勤日数チェック
    -- 必要人数チェック
    -- その他制約チェック
    -- 違反があれば constraint_violations テーブルに記録
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER check_constraints_on_shift_insert AFTER INSERT ON app_9213e72257_shifts
    FOR EACH ROW EXECUTE FUNCTION check_shift_constraints();
```

## 7. パフォーマンス最適化

### 7.1 パーティショニング
```sql
-- 大量データ対応のための月次パーティショニング
CREATE TABLE app_9213e72257_shifts_y2024m01 PARTITION OF app_9213e72257_shifts
    FOR VALUES FROM ('2024-01-01') TO ('2024-02-01');
```

### 7.2 マテリアライズドビュー
```sql
-- シフト統計用マテリアライズドビュー
CREATE MATERIALIZED VIEW shift_statistics AS
SELECT 
    shift_date,
    COUNT(*) as total_shifts,
    COUNT(DISTINCT employee_id) as unique_employees,
    COUNT(DISTINCT business_id) as covered_businesses
FROM app_9213e72257_shifts
WHERE shift_status = 'confirmed'
GROUP BY shift_date;

CREATE UNIQUE INDEX ON shift_statistics (shift_date);
```

## 8. データ整合性制約

```sql
-- シフト時間の論理チェック
ALTER TABLE app_9213e72257_shifts 
ADD CONSTRAINT check_shift_time_logic 
CHECK (start_time < end_time);

-- 制約値の妥当性チェック
ALTER TABLE app_9213e72257_shift_constraints 
ADD CONSTRAINT check_constraint_value_format 
CHECK (jsonb_typeof(constraint_value) = 'object');
```

この設計により、柔軟で拡張可能なシフト自動生成システムの基盤を構築できます。