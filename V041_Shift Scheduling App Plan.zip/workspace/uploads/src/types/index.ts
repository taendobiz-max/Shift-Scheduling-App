export interface Employee {
  id: string;
  name: string;
  employeeNumber: string;
  depot: string;
  employmentType: 'full-time' | 'part-time' | 'contract';
  skills: string[];
  maxConsecutiveDays: number;
  monthlyHourLimit: number;
  specialNotes?: string;
  isActive: boolean;
  userType: number; // 0: 参照ユーザ, 1: 管理者（シフト作成者）
}

export interface ShiftType {
  id: string;
  name: string;
  startTime: string;
  endTime: string;
  requiredStaff: number;
  allowanceEligible: boolean;
  description?: string;
}

export interface Shift {
  id: string;
  date: string;
  employeeId: string;
  shiftTypeId: string;
  status: 'assigned' | 'confirmed' | 'completed';
}

export interface LeaveRequest {
  id: string;
  employeeId: string;
  startDate: string;
  endDate: string;
  reason: string;
  status: 'pending' | 'approved' | 'rejected';
  submittedAt: string;
  approvedAt?: string;
  rejectedAt?: string;
  notes?: string;
}