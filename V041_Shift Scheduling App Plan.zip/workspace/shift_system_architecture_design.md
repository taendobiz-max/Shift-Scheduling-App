# シフト自動作成システム - システム設計書

## 1. システム概要

### 1.1 システム目的
- 業務ルールと制約条件を満たした最適なシフトの自動生成
- 従業員の公平性と業務効率性を両立
- 手動調整機能による柔軟な運用支援

### 1.2 システム構成
```mermaid
graph TB
    UI[React Frontend] --> API[Supabase API Layer]
    API --> DB[(Supabase Database)]
    API --> Engine[Shift Generation Engine]
    Engine --> Optimizer[Constraint Optimizer]
    Engine --> Validator[Constraint Validator]
    Engine --> Logger[Generation Logger]
```

## 2. アーキテクチャ設計

### 2.1 レイヤー構成

#### 2.1.1 プレゼンテーション層 (React + TypeScript)
```typescript
// コンポーネント構成
src/
├── pages/
│   ├── ShiftManagement.tsx          // シフト管理メイン画面
│   ├── ShiftCalendar.tsx            // カレンダー表示
│   ├── ConstraintManagement.tsx     // 制約管理画面
│   └── ShiftGeneration.tsx          // 自動生成画面
├── components/
│   ├── shift/
│   │   ├── ShiftCard.tsx            // シフト表示カード
│   │   ├── ShiftEditModal.tsx       // シフト編集モーダル
│   │   └── GenerationProgress.tsx   // 生成進捗表示
│   └── constraints/
│       ├── ConstraintForm.tsx       // 制約設定フォーム
│       └── ViolationAlert.tsx       // 制約違反アラート
└── utils/
    ├── shiftGenerator.ts            // シフト生成ロジック
    ├── constraintValidator.ts       // 制約検証ロジック
    └── optimizationEngine.ts        // 最適化エンジン
```

#### 2.1.2 ビジネスロジック層
```typescript
// シフト生成エンジンの構成
interface ShiftGenerationEngine {
  generateShifts(params: GenerationParams): Promise<GenerationResult>;
  validateConstraints(shifts: Shift[]): ConstraintViolation[];
  optimizeAssignments(shifts: Shift[]): OptimizedShifts;
}

interface GenerationParams {
  startDate: Date;
  endDate: Date;
  constraints: Constraint[];
  preferences: EmployeePreference[];
  existingShifts?: Shift[];
}
```

#### 2.1.3 データアクセス層 (Supabase)
```typescript
// データアクセスインターface
interface ShiftRepository {
  getShifts(dateRange: DateRange): Promise<Shift[]>;
  createShifts(shifts: Shift[]): Promise<void>;
  updateShift(id: string, shift: Partial<Shift>): Promise<void>;
  deleteShift(id: string): Promise<void>;
}

interface ConstraintRepository {
  getConstraints(): Promise<Constraint[]>;
  createConstraint(constraint: Constraint): Promise<void>;
  updateConstraint(id: string, constraint: Partial<Constraint>): Promise<void>;
}
```

## 3. シフト自動生成アルゴリズム

### 3.1 アルゴリズム選択方針

#### 3.1.1 制約充足問題 (CSP) アプローチ
```typescript
class ConstraintSatisfactionSolver {
  private constraints: Constraint[];
  private variables: Variable[];
  private domains: Domain[];

  solve(): Solution {
    // バックトラッキング + 制約伝搬
    return this.backtrackWithConstraintPropagation();
  }

  private backtrackWithConstraintPropagation(): Solution {
    // 1. 変数選択（最小残り値ヒューリスティック）
    // 2. 値選択（最小制約値ヒューリスティック）
    // 3. 制約伝搬（アーク一貫性）
    // 4. バックトラッキング
  }
}
```

#### 3.1.2 遺伝的アルゴリズム（大規模データ対応）
```typescript
class GeneticAlgorithmSolver {
  private populationSize: number = 100;
  private generations: number = 1000;
  private mutationRate: number = 0.1;

  solve(problem: ShiftProblem): Solution {
    let population = this.initializePopulation(problem);
    
    for (let gen = 0; gen < this.generations; gen++) {
      population = this.evolve(population);
      if (this.isOptimal(population[0])) break;
    }
    
    return population[0];
  }

  private fitness(individual: Individual): number {
    // 制約違反ペナルティ + 最適化目標スコア
    return this.calculateConstraintScore(individual) + 
           this.calculateOptimizationScore(individual);
  }
}
```

### 3.2 制約条件の実装

#### 3.2.1 ハード制約（必須条件）
```typescript
class HardConstraints {
  // 最大連続出勤日数制約
  checkMaxConsecutiveDays(shifts: Shift[], employeeId: string): boolean {
    const employeeShifts = shifts.filter(s => s.employeeId === employeeId)
                                 .sort((a, b) => a.date.getTime() - b.date.getTime());
    
    let consecutiveDays = 0;
    let maxConsecutive = 0;
    
    for (let i = 0; i < employeeShifts.length; i++) {
      if (i === 0 || this.isConsecutiveDay(employeeShifts[i-1].date, employeeShifts[i].date)) {
        consecutiveDays++;
        maxConsecutive = Math.max(maxConsecutive, consecutiveDays);
      } else {
        consecutiveDays = 1;
      }
    }
    
    return maxConsecutive <= 6; // 最大6日連続
  }

  // 業務カバレッジ制約
  checkBusinessCoverage(shifts: Shift[], date: Date): boolean {
    const businessesOnDate = new Set(
      shifts.filter(s => s.date.getTime() === date.getTime())
            .map(s => s.businessId)
    );
    
    const requiredBusinesses = this.getRequiredBusinesses(date);
    return requiredBusinesses.every(business => businessesOnDate.has(business));
  }
}
```

#### 3.2.2 ソフト制約（最適化目標）
```typescript
class SoftConstraints {
  // 公平性制約（労働時間の均等化）
  calculateFairnessScore(shifts: Shift[]): number {
    const workHoursByEmployee = this.calculateWorkHours(shifts);
    const average = Object.values(workHoursByEmployee).reduce((a, b) => a + b, 0) / 
                   Object.keys(workHoursByEmployee).length;
    
    const variance = Object.values(workHoursByEmployee)
                          .reduce((sum, hours) => sum + Math.pow(hours - average, 2), 0) / 
                     Object.keys(workHoursByEmployee).length;
    
    return 1 / (1 + variance); // 分散が小さいほど高スコア
  }

  // 従業員希望適合度
  calculatePreferenceScore(shifts: Shift[], preferences: EmployeePreference[]): number {
    let totalScore = 0;
    let totalPreferences = 0;

    for (const preference of preferences) {
      const matchingShifts = shifts.filter(s => 
        s.employeeId === preference.employeeId && 
        s.date.getTime() === preference.date.getTime()
      );

      if (matchingShifts.length > 0) {
        totalScore += preference.priority / 100;
      }
      totalPreferences++;
    }

    return totalPreferences > 0 ? totalScore / totalPreferences : 0;
  }
}
```

## 4. API設計

### 4.1 シフト生成API
```typescript
// POST /api/shifts/generate
interface GenerateShiftsRequest {
  startDate: string;
  endDate: string;
  constraints?: ConstraintOverride[];
  preserveExisting?: boolean;
  optimizationGoals?: OptimizationGoal[];
}

interface GenerateShiftsResponse {
  generationId: string;
  status: 'started' | 'completed' | 'failed';
  shifts?: Shift[];
  violations?: ConstraintViolation[];
  statistics?: GenerationStatistics;
}
```

### 4.2 制約管理API
```typescript
// GET /api/constraints
interface GetConstraintsResponse {
  constraints: Constraint[];
}

// POST /api/constraints
interface CreateConstraintRequest {
  type: ConstraintType;
  name: string;
  value: any;
  businessGroup?: string;
  employeeId?: string;
  priority: number;
}

// PUT /api/constraints/:id
interface UpdateConstraintRequest {
  name?: string;
  value?: any;
  priority?: number;
  isActive?: boolean;
}
```

### 4.3 シフト操作API
```typescript
// GET /api/shifts
interface GetShiftsRequest {
  startDate: string;
  endDate: string;
  employeeId?: string;
  businessId?: string;
  status?: ShiftStatus;
}

// POST /api/shifts
interface CreateShiftRequest {
  date: string;
  employeeId: string;
  businessId: string;
  startTime: string;
  endTime: string;
  assignmentType: 'manual' | 'auto';
}

// PUT /api/shifts/:id
interface UpdateShiftRequest {
  employeeId?: string;
  businessId?: string;
  startTime?: string;
  endTime?: string;
  status?: ShiftStatus;
  notes?: string;
}
```

## 5. パフォーマンス設計

### 5.1 計算量最適化
```typescript
class PerformanceOptimizer {
  // 大規模データ対応のための分割統治法
  generateLargeScale(params: GenerationParams): Promise<GenerationResult> {
    const chunks = this.divideTimeRange(params.startDate, params.endDate, 7); // 週単位分割
    const results = await Promise.all(
      chunks.map(chunk => this.generateChunk(chunk))
    );
    
    return this.mergeResults(results);
  }

  // キャッシュ戦略
  private constraintCache = new Map<string, ConstraintResult>();
  
  checkConstraintCached(constraint: Constraint, context: any): ConstraintResult {
    const key = this.generateCacheKey(constraint, context);
    if (this.constraintCache.has(key)) {
      return this.constraintCache.get(key)!;
    }
    
    const result = this.checkConstraint(constraint, context);
    this.constraintCache.set(key, result);
    return result;
  }
}
```

### 5.2 並列処理設計
```typescript
class ParallelProcessor {
  async generateShiftsParallel(params: GenerationParams): Promise<GenerationResult> {
    // Web Workers を使用した並列計算
    const workers = await this.createWorkerPool(4);
    
    try {
      const tasks = this.divideTasks(params);
      const results = await Promise.all(
        tasks.map((task, index) => workers[index % workers.length].process(task))
      );
      
      return this.combineResults(results);
    } finally {
      workers.forEach(worker => worker.terminate());
    }
  }
}
```

## 6. エラーハンドリング設計

### 6.1 制約違反処理
```typescript
class ConstraintViolationHandler {
  handleViolations(violations: ConstraintViolation[]): Resolution[] {
    return violations.map(violation => {
      switch (violation.severity) {
        case 'critical':
          return this.handleCriticalViolation(violation);
        case 'error':
          return this.handleErrorViolation(violation);
        case 'warning':
          return this.handleWarningViolation(violation);
        default:
          return this.handleInfoViolation(violation);
      }
    });
  }

  private handleCriticalViolation(violation: ConstraintViolation): Resolution {
    // 自動修正を試行
    const autoFix = this.attemptAutoFix(violation);
    if (autoFix.success) {
      return { type: 'auto_fixed', action: autoFix.action };
    }
    
    // 手動対応が必要
    return { 
      type: 'manual_required', 
      message: '重大な制約違反が発生しました。手動での調整が必要です。',
      suggestions: this.generateSuggestions(violation)
    };
  }
}
```

### 6.2 生成失敗時のフォールバック
```typescript
class FallbackStrategy {
  async generateWithFallback(params: GenerationParams): Promise<GenerationResult> {
    try {
      // 主要アルゴリズムで生成試行
      return await this.primaryAlgorithm.generate(params);
    } catch (error) {
      console.warn('Primary algorithm failed, trying fallback:', error);
      
      try {
        // 制約を緩和して再試行
        const relaxedParams = this.relaxConstraints(params);
        return await this.fallbackAlgorithm.generate(relaxedParams);
      } catch (fallbackError) {
        // 最低限のシフトを生成
        return await this.generateMinimalShifts(params);
      }
    }
  }
}
```

## 7. モニタリング・ログ設計

### 7.1 生成プロセス監視
```typescript
class GenerationMonitor {
  async monitorGeneration(generationId: string): Promise<void> {
    const monitor = setInterval(async () => {
      const status = await this.getGenerationStatus(generationId);
      
      // 進捗をリアルタイム更新
      this.broadcastProgress(generationId, status);
      
      // タイムアウトチェック
      if (status.elapsedTime > this.maxExecutionTime) {
        await this.cancelGeneration(generationId);
        clearInterval(monitor);
      }
      
      if (status.status === 'completed' || status.status === 'failed') {
        clearInterval(monitor);
      }
    }, 1000);
  }
}
```

### 7.2 パフォーマンス分析
```typescript
class PerformanceAnalyzer {
  analyzeGeneration(history: GenerationHistory): AnalysisResult {
    return {
      averageExecutionTime: this.calculateAverageTime(history),
      constraintViolationTrends: this.analyzeViolationTrends(history),
      optimizationScoreTrends: this.analyzeScoreTrends(history),
      algorithmEfficiency: this.compareAlgorithms(history),
      recommendations: this.generateRecommendations(history)
    };
  }
}
```

この設計により、スケーラブルで保守性の高いシフト自動生成システムを構築できます。