# シフト自動作成システム - API仕様書

## 1. API概要

### 1.1 ベースURL
```
https://your-project.supabase.co/rest/v1/
```

### 1.2 認証
```typescript
Authorization: Bearer <supabase_anon_key>
apikey: <supabase_anon_key>
```

### 1.3 共通レスポンス形式
```typescript
interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: {
    code: string;
    message: string;
    details?: any;
  };
  metadata?: {
    timestamp: string;
    requestId: string;
    executionTime: number;
  };
}
```

## 2. シフト生成API

### 2.1 シフト自動生成開始
```http
POST /rpc/generate_shifts
```

#### リクエスト
```typescript
interface GenerateShiftsRequest {
  start_date: string;           // YYYY-MM-DD
  end_date: string;             // YYYY-MM-DD
  generation_type?: 'full' | 'partial' | 'optimization';
  preserve_existing?: boolean;   // 既存シフトを保持するか
  constraint_overrides?: ConstraintOverride[];
  optimization_goals?: OptimizationGoal[];
}

interface ConstraintOverride {
  constraint_id: string;
  override_value: any;
  reason?: string;
}

interface OptimizationGoal {
  type: 'fairness' | 'preference' | 'efficiency' | 'cost';
  weight: number;  // 0-100
  parameters?: any;
}
```

#### レスポンス
```typescript
interface GenerateShiftsResponse {
  generation_id: string;
  status: 'started' | 'queued';
  estimated_completion_time: string;
  target_period: {
    start_date: string;
    end_date: string;
  };
}
```

#### 実装例
```typescript
const generateShifts = async (params: GenerateShiftsRequest): Promise<GenerateShiftsResponse> => {
  const { data, error } = await supabase.rpc('generate_shifts', params);
  
  if (error) {
    throw new Error(`Shift generation failed: ${error.message}`);
  }
  
  return data;
};
```

### 2.2 生成状況確認
```http
GET /rpc/get_generation_status?generation_id={id}
```

#### レスポンス
```typescript
interface GenerationStatusResponse {
  generation_id: string;
  status: 'running' | 'completed' | 'failed' | 'cancelled';
  progress: {
    current_step: string;
    completed_steps: number;
    total_steps: number;
    percentage: number;
  };
  statistics?: {
    total_shifts_generated: number;
    constraint_violations: number;
    optimization_score: number;
    execution_time_ms: number;
  };
  error_message?: string;
}
```

### 2.3 生成結果取得
```http
GET /rpc/get_generation_result?generation_id={id}
```

#### レスポンス
```typescript
interface GenerationResultResponse {
  generation_id: string;
  shifts: Shift[];
  violations: ConstraintViolation[];
  statistics: GenerationStatistics;
  recommendations?: string[];
}

interface Shift {
  id: string;
  shift_date: string;
  employee_id: string;
  business_id: string;
  start_time: string;
  end_time: string;
  assignment_type: 'auto' | 'manual';
  shift_status: 'draft' | 'confirmed' | 'published';
}

interface ConstraintViolation {
  id: string;
  violation_type: string;
  severity: 'info' | 'warning' | 'error' | 'critical';
  description: string;
  affected_employee_id?: string;
  affected_date?: string;
  suggested_resolution?: string;
}
```

## 3. シフト管理API

### 3.1 シフト一覧取得
```http
GET /app_9213e72257_shifts?select=*&shift_date=gte.{start_date}&shift_date=lte.{end_date}
```

#### クエリパラメータ
```typescript
interface GetShiftsParams {
  start_date?: string;
  end_date?: string;
  employee_id?: string;
  business_id?: string;
  shift_status?: 'draft' | 'confirmed' | 'published' | 'cancelled';
  assignment_type?: 'auto' | 'manual' | 'adjusted';
  limit?: number;
  offset?: number;
}
```

#### 実装例
```typescript
const getShifts = async (params: GetShiftsParams): Promise<Shift[]> => {
  let query = supabase
    .from('app_9213e72257_shifts')
    .select(`
      *,
      app_9213e72257_employees!inner(employee_id, name),
      app_9213e72257_business_master!inner(業務id, 業務名, 開始時間, 終了時間)
    `);

  if (params.start_date) {
    query = query.gte('shift_date', params.start_date);
  }
  if (params.end_date) {
    query = query.lte('shift_date', params.end_date);
  }
  if (params.employee_id) {
    query = query.eq('employee_id', params.employee_id);
  }
  if (params.business_id) {
    query = query.eq('business_id', params.business_id);
  }
  if (params.shift_status) {
    query = query.eq('shift_status', params.shift_status);
  }

  const { data, error } = await query;
  
  if (error) {
    throw new Error(`Failed to fetch shifts: ${error.message}`);
  }
  
  return data || [];
};
```

### 3.2 シフト作成
```http
POST /app_9213e72257_shifts
```

#### リクエスト
```typescript
interface CreateShiftRequest {
  shift_date: string;
  employee_id: string;
  business_id: string;
  start_time: string;
  end_time: string;
  assignment_type: 'manual' | 'auto';
  notes?: string;
}
```

#### 実装例
```typescript
const createShift = async (shift: CreateShiftRequest): Promise<Shift> => {
  // 制約チェック
  const violations = await validateShiftConstraints(shift);
  if (violations.some(v => v.severity === 'critical' || v.severity === 'error')) {
    throw new Error('Constraint violations detected');
  }

  const { data, error } = await supabase
    .from('app_9213e72257_shifts')
    .insert(shift)
    .select()
    .single();

  if (error) {
    throw new Error(`Failed to create shift: ${error.message}`);
  }

  return data;
};
```

### 3.3 シフト更新
```http
PATCH /app_9213e72257_shifts?id=eq.{shift_id}
```

#### リクエスト
```typescript
interface UpdateShiftRequest {
  employee_id?: string;
  business_id?: string;
  start_time?: string;
  end_time?: string;
  shift_status?: 'draft' | 'confirmed' | 'published' | 'cancelled';
  notes?: string;
}
```

### 3.4 シフト削除
```http
DELETE /app_9213e72257_shifts?id=eq.{shift_id}
```

## 4. 制約管理API

### 4.1 制約一覧取得
```http
GET /app_9213e72257_shift_constraints
```

#### レスポンス
```typescript
interface Constraint {
  id: string;
  constraint_type: string;
  constraint_name: string;
  constraint_value: any;
  business_group?: string;
  employee_id?: string;
  priority: number;
  is_active: boolean;
  effective_from?: string;
  effective_to?: string;
}
```

### 4.2 制約作成
```http
POST /app_9213e72257_shift_constraints
```

#### リクエスト
```typescript
interface CreateConstraintRequest {
  constraint_type: string;
  constraint_name: string;
  constraint_value: any;
  business_group?: string;
  employee_id?: string;
  priority: number;
  effective_from?: string;
  effective_to?: string;
}
```

### 4.3 制約検証
```http
POST /rpc/validate_constraints
```

#### リクエスト
```typescript
interface ValidateConstraintsRequest {
  shifts: Shift[];
  constraint_ids?: string[];  // 特定制約のみ検証
}
```

#### レスポンス
```typescript
interface ValidateConstraintsResponse {
  is_valid: boolean;
  violations: ConstraintViolation[];
  warnings: ConstraintViolation[];
}
```

## 5. 従業員希望管理API

### 5.1 希望シフト登録
```http
POST /app_9213e72257_employee_preferences
```

#### リクエスト
```typescript
interface CreatePreferenceRequest {
  employee_id: string;
  preference_date: string;
  preference_type: 'available' | 'unavailable' | 'preferred' | 'avoid';
  business_group?: string;
  time_slot_start?: string;
  time_slot_end?: string;
  priority: number;  // 1-100
  reason?: string;
}
```

### 5.2 希望シフト一覧取得
```http
GET /app_9213e72257_employee_preferences?employee_id=eq.{employee_id}&preference_date=gte.{start_date}&preference_date=lte.{end_date}
```

## 6. 統計・分析API

### 6.1 シフト統計取得
```http
GET /rpc/get_shift_statistics?start_date={start_date}&end_date={end_date}
```

#### レスポンス
```typescript
interface ShiftStatistics {
  period: {
    start_date: string;
    end_date: string;
  };
  total_shifts: number;
  unique_employees: number;
  coverage_rate: number;  // 業務カバー率
  fairness_score: number; // 公平性スコア
  constraint_compliance_rate: number;
  employee_statistics: {
    employee_id: string;
    employee_name: string;
    total_shifts: number;
    total_hours: number;
    consecutive_days_max: number;
  }[];
  business_statistics: {
    business_id: string;
    business_name: string;
    coverage_days: number;
    assigned_employees: number;
  }[];
}
```

### 6.2 制約違反レポート
```http
GET /rpc/get_violation_report?start_date={start_date}&end_date={end_date}
```

#### レスポンス
```typescript
interface ViolationReport {
  period: {
    start_date: string;
    end_date: string;
  };
  total_violations: number;
  violations_by_severity: {
    critical: number;
    error: number;
    warning: number;
    info: number;
  };
  violations_by_type: {
    [key: string]: number;
  };
  top_violations: ConstraintViolation[];
  recommendations: string[];
}
```

## 7. リアルタイム更新API

### 7.1 WebSocket接続
```typescript
// Supabase Realtime を使用
const subscription = supabase
  .channel('shift_updates')
  .on('postgres_changes', 
    { 
      event: '*', 
      schema: 'public', 
      table: 'app_9213e72257_shifts' 
    }, 
    (payload) => {
      console.log('Shift updated:', payload);
      // UIを更新
    }
  )
  .subscribe();
```

### 7.2 生成進捗の購読
```typescript
const subscribeToGenerationProgress = (generationId: string) => {
  return supabase
    .channel(`generation_${generationId}`)
    .on('postgres_changes',
      {
        event: 'UPDATE',
        schema: 'public',
        table: 'app_9213e72257_shift_generation_history',
        filter: `generation_id=eq.${generationId}`
      },
      (payload) => {
        // 進捗更新を処理
        updateProgressUI(payload.new);
      }
    )
    .subscribe();
};
```

## 8. エラーハンドリング

### 8.1 エラーコード定義
```typescript
enum ShiftApiErrorCode {
  CONSTRAINT_VIOLATION = 'CONSTRAINT_VIOLATION',
  GENERATION_FAILED = 'GENERATION_FAILED',
  INVALID_DATE_RANGE = 'INVALID_DATE_RANGE',
  EMPLOYEE_NOT_FOUND = 'EMPLOYEE_NOT_FOUND',
  BUSINESS_NOT_FOUND = 'BUSINESS_NOT_FOUND',
  INSUFFICIENT_PERMISSIONS = 'INSUFFICIENT_PERMISSIONS',
  GENERATION_IN_PROGRESS = 'GENERATION_IN_PROGRESS',
  OPTIMIZATION_TIMEOUT = 'OPTIMIZATION_TIMEOUT'
}
```

### 8.2 エラーレスポンス例
```typescript
interface ErrorResponse {
  success: false;
  error: {
    code: ShiftApiErrorCode;
    message: string;
    details?: {
      violations?: ConstraintViolation[];
      suggestions?: string[];
      retry_after?: number;
    };
  };
}
```

## 9. レート制限

### 9.1 制限設定
```typescript
const rateLimits = {
  'generate_shifts': '5 requests per minute',
  'validate_constraints': '60 requests per minute',
  'get_shifts': '100 requests per minute',
  'create_shift': '30 requests per minute'
};
```

### 9.2 制限超過時のレスポンス
```http
HTTP/1.1 429 Too Many Requests
Retry-After: 60

{
  "success": false,
  "error": {
    "code": "RATE_LIMIT_EXCEEDED",
    "message": "Rate limit exceeded. Try again in 60 seconds."
  }
}
```

この API 仕様により、フロントエンドアプリケーションから効率的にシフト自動生成システムを操作できます。